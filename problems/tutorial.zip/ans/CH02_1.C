#include <stdio.h>

int main()
{
   printf("John Q. Doe\n");

   return 0;
}



/* Result of execution

John Q. Doe

*/
