#include <stdio.h>

int main()
{
int index;

   for(index = 0 ; index < 10 ; index = index + 1)
      printf("John Q. Doe\n");

   return 0;
}



/* Result of execution

John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe

*/
