#include <stdio.h>

int main()
{
int index;

   index = 0;
   do 
   {
      printf("John Q. Doe\n");
      index = index + 1;
   } while (index < 10);

   return 0;
}



/* Result of execution

John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe

*/
