#include <stdio.h>

int main()
{
   printf("John Q. Doe\n");
   printf("1234 Main Street\n");
   printf("(505) 555-1212\n");

   return 0;
}



/* Result of execution

John Q. Doe
1234 Main Street
(505) 555-1212

*/
