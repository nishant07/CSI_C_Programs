#include <stdio.h>

int main()
{
int index;

   index = 0;
   while (index < 10) 
   {
      printf("John Q. Doe\n");
      index = index + 1;
   }

   return 0;
}



/* Result of execution

John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe
John Q. Doe

*/
