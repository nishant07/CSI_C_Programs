#include <stdio.h>

int main()
{
   printf("This is a line of text to output.");

   return 0;
}
